<?php
/*
 * Plugin Name: Simple Scroll To Top iM
 * Plugin URI: developerimdadul.me
 * Text Domain: ssttim
 * Description: Simple Scroll to top plugin
 * Version: 1.0.0
 * Author: Imdadul Haque
 * Author URI: developerimdadul.me
 * Requires at least: 6.1
 * Requires PHP: 7.2
*/


// Including CSS
function ssttim_enqueue_style()
{
    wp_enqueue_style('ssttim_style', plugins_url('css/ssttim_style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'ssttim_enqueue_style');
// Including JS
function ssttim_enqueue_scripts()
{
    wp_enqueue_script('jquery');
    wp_enqueue_script('ssttim_plugin_script', plugins_url('js/ssttim_scrollUp.js', __FILE__), array(), '1.0.0', 'true');
}
add_action('wp_enqueue_scripts', 'ssttim_enqueue_scripts');

// jQuery Plugin Setting Activation 
function ssttim_scroll_script()
{
    ?>
        <script>
            jQuery(document).ready(function() {
                jQuery.scrollUp();
            });
        </script>
    <?php
}
add_action('wp_footer', 'ssttim_scroll_script');
// --------------------------------------------------------


?>